sampleName = 'Sample10Cropped.tif'

sample = imread(strcat('smooth\', sampleName, '_smooth500.png'));

%f = fft2(sample);

%fmag = log(f .* conj(f));

sampleNotSmoothed = imread(sampleName);

%f2 = fft2(sampleNotSmoothed);

%fmag2 = log(f2 .* conj(f2));

%imagesc(real(fmag2))

%imshow(sample)

CannParam1 = 0.4
CannParam2 = 2.5

CannyFiltered = edge(sample, 'Canny',CannParam1,CannParam2);

PrewittFiltered = edge(sample, 'Prewitt',0.5);

%%imshowpair(CannyFiltered,sample, 'montage')
    
hold on;

imagesc(CannyFiltered)

hold off;

CannParam1 = num2str(CannParam1)
CannParam2 = num2str(CannParam2)

imwrite(CannyFiltered, strcat('CannyFilter\',CannParam1,'\',sampleName(1:end-4),'_',CannParam1,'_',CannParam2,'_Canny.tif'));


%figure

% kw=10;
% [X,Y]=meshgrid(-kw:kw,-kw:kw);
% rmax=3.5;
% R=sqrt(X.*X+Y.*Y);
% circ_kern=(R<=rmax);
% imagesc(circ_kern);
% Canny2=conv2(CannyFiltered,circ_kern,'same');
% SE=strel('disk',3,8);
% Canny3=imerode(Canny2,SE);
% subplot(1,3,1)
% imagesc(CannyFiltered)
% axis equal
% subplot(1,3,2)
% imagesc(Canny2>0)
% axis equal
% subplot(1,3,3)
% imagesc(Canny3>0)
% axis equal
