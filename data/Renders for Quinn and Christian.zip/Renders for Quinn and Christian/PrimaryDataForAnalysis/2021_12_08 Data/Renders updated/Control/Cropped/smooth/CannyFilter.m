sample = imread('sample15Cropped.tif_smooth500.png');

imshow(sample)

CannyFiltered = edge(sample, 'Canny',0.45,2.5);

PrewittFiltered = edge(sample, 'Prewitt',0.5);

%%imshowpair(CannyFiltered,sample, 'montage')

hold on;

contour(CannyFiltered)